package com.oz.ozHouse.dto;

public class InbrandDTO {

	private int inbrand_num;
	private int mer_num;
	private String inbrand_company;
	private String inbrand_comnum1;
	private String inbrand_comnum2;
	private String inbrand_comnum3;
	private String inbrand_homepage;
	private String inbrand_manname;
	private String inbrand_manhp1;
	private String inbrand_manhp2;
	private String inbrand_manhp3;
	private String inbrand_manemail;
	private String inbrand_category;
	private String inbrand_othershop;
	private String inbrand_file;
	private String inbrand_applicationdate;
	private String inbrand_canceldate;
	public int getInbrand_num() {
		return inbrand_num;
	}
	public void setInbrand_num(int inbrand_num) {
		this.inbrand_num = inbrand_num;
	}
	public int getMer_num() {
		return mer_num;
	}
	public void setMer_num(int mer_num) {
		this.mer_num = mer_num;
	}
	public String getInbrand_company() {
		return inbrand_company;
	}
	public void setInbrand_company(String inbrand_company) {
		this.inbrand_company = inbrand_company;
	}
	public String getInbrand_comnum1() {
		return inbrand_comnum1;
	}
	public void setInbrand_comnum1(String inbrand_comnum1) {
		this.inbrand_comnum1 = inbrand_comnum1;
	}
	public String getInbrand_comnum2() {
		return inbrand_comnum2;
	}
	public void setInbrand_comnum2(String inbrand_comnum2) {
		this.inbrand_comnum2 = inbrand_comnum2;
	}
	public String getInbrand_comnum3() {
		return inbrand_comnum3;
	}
	public void setInbrand_comnum3(String inbrand_comnum3) {
		this.inbrand_comnum3 = inbrand_comnum3;
	}
	public String getInbrand_homepage() {
		return inbrand_homepage;
	}
	public void setInbrand_homepage(String inbrand_homepage) {
		this.inbrand_homepage = inbrand_homepage;
	}
	public String getInbrand_manname() {
		return inbrand_manname;
	}
	public void setInbrand_manname(String inbrand_manname) {
		this.inbrand_manname = inbrand_manname;
	}
	public String getInbrand_manhp1() {
		return inbrand_manhp1;
	}
	public void setInbrand_manhp1(String inbrand_manhp1) {
		this.inbrand_manhp1 = inbrand_manhp1;
	}
	public String getInbrand_manhp2() {
		return inbrand_manhp2;
	}
	public void setInbrand_manhp2(String inbrand_manhp2) {
		this.inbrand_manhp2 = inbrand_manhp2;
	}
	public String getInbrand_manhp3() {
		return inbrand_manhp3;
	}
	public void setInbrand_manhp3(String inbrand_manhp3) {
		this.inbrand_manhp3 = inbrand_manhp3;
	}
	public String getInbrand_manemail() {
		return inbrand_manemail;
	}
	public void setInbrand_manemail(String inbrand_manemail) {
		this.inbrand_manemail = inbrand_manemail;
	}
	public String getInbrand_category() {
		return inbrand_category;
	}
	public void setInbrand_category(String inbrand_category) {
		this.inbrand_category = inbrand_category;
	}
	public String getInbrand_othershop() {
		return inbrand_othershop;
	}
	public void setInbrand_othershop(String inbrand_othershop) {
		this.inbrand_othershop = inbrand_othershop;
	}
	public String getInbrand_file() {
		return inbrand_file;
	}
	public void setInbrand_file(String inbrand_file) {
		this.inbrand_file = inbrand_file;
	}
	public String getInbrand_applicationdate() {
		return inbrand_applicationdate;
	}
	public void setInbrand_applicationdate(String inbrand_applicationdate) {
		this.inbrand_applicationdate = inbrand_applicationdate;
	}
	public String getInbrand_canceldate() {
		return inbrand_canceldate;
	}
	public void setInbrand_canceldate(String inbrand_canceldate) {
		this.inbrand_canceldate = inbrand_canceldate;
	}
}
