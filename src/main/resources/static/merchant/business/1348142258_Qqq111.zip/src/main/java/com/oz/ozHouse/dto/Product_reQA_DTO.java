package com.oz.ozHouse.dto;

public class Product_reQA_DTO {

	private int product_reQA_num;
	private int product_num;
	private String member_id;
	private String product_reQA_content;
	private String product_reQA_date;
	
	public int getProduct_reQA_num() {
		return product_reQA_num;
	}
	public void setProduct_reQA_num(int product_reQA_num) {
		this.product_reQA_num = product_reQA_num;
	}
	public int getProduct_num() {
		return product_num;
	}
	public void setProduct_num(int product_num) {
		this.product_num = product_num;
	}
	public String getMember_id() {
		return member_id;
	}
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}
	public String getProduct_reQA_content() {
		return product_reQA_content;
	}
	public void setProduct_reQA_content(String product_reQA_content) {
		this.product_reQA_content = product_reQA_content;
	}
	public String getProduct_reQA_date() {
		return product_reQA_date;
	}
	public void setProduct_reQA_date(String product_reQA_date) {
		this.product_reQA_date = product_reQA_date;
	}
	
}
