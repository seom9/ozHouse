package com.oz.ozHouse.dto;

public class Order_QADTO {

	private int order_QA_num ;
	private String member_id;
	private String order_QA_content;
	private String order_QA_date;
	private String order_inquiry_type;
	private String order_QA_state;
	private int order_num;
	private int mer_num;

	public int getMer_num() {
		return mer_num;
	}
	public void setMer_num(int mer_num) {
		this.mer_num = mer_num;
	}
	public int getOrder_num() {
		return order_num;
	}
	public void setOrder_num(int order_num) {
		this.order_num = order_num;
	}
public int getOrder_QA_num() {
		return order_QA_num;
	}
	public void setOrder_QA_num(int order_QA_num) {
		this.order_QA_num = order_QA_num;
	}
	public String getMember_id() {
		return member_id;
	}
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}
	public String getOrder_QA_content() {
		return order_QA_content;
	}
	public void setOrder_QA_content(String order_QA_content) {
		this.order_QA_content = order_QA_content;
	}
	public String getOrder_QA_date() {
		return order_QA_date;
	}
	public void setOrder_QA_date(String order_QA_date) {
		this.order_QA_date = order_QA_date;
	}
	public String getOrder_inquiry_type() {
		return order_inquiry_type;
	}
	public void setOrder_inquiry_type(String order_inquiry_type) {
		this.order_inquiry_type = order_inquiry_type;
	}
	public String getOrder_QA_state() {
		return order_QA_state;
	}
	public void setOrder_QA_state(String order_QA_state) {
		this.order_QA_state = order_QA_state;
	}
	
	
	
}
