package com.oz.ozHouse.merchant;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.oz.ozHouse.dto.CategoryDTO;
import com.oz.ozHouse.dto.MerchantDTO;
import com.oz.ozHouse.merchant.service.MerchantLoginMapper;
import com.oz.ozHouse.merchant.service.ProductManagementMapper;
import com.oz.ozHouse.merchant.bean.*;


@Controller
public class MerchantLoginController {
	@Autowired
	private MerchantLoginMapper merchantMapper;
	
	@RequestMapping(value="/merchant_login.do", method=RequestMethod.GET)
	public String login() {
		return "merchant/join/merchant_login";
	}
	@RequestMapping(value="/merchant_login.do", method=RequestMethod.POST)
	public String loginOk(HttpServletRequest req, HttpServletResponse resp, 
			@ModelAttribute MerchantLoginBean loginOk, @RequestParam(required=false) String saveId) {
		int res = loginOk.loginOk(merchantMapper);
		String msg = null, url = null;
		switch(res){
		case MerchantLoginBean.OK :
			Cookie ck = new Cookie("saveId", loginOk.getMer_id());
			if (saveId != null) {
				ck.setMaxAge(7*24*60*60);
			}else {
				ck.setMaxAge(0);
			}
			resp.addCookie(ck);
			HttpSession session = req.getSession();
			session.setAttribute("loginMember", loginOk);
			msg = loginOk.getMer_id() + "님, OZ의 집에 오신걸 환영합니다.";
			url = "main.do";
			break;
		case MerchantLoginBean.NOT_ID :
			msg = "아이디 확인 후 다시 시도해 주세요";
			url = "merchant_login.do";
			break;
		case MerchantLoginBean.NOT_PW :
			msg = "비밀번호 확인 후 다시 시도해 주세요";
			url = "merchant_login.do";
			break;
		case MerchantLoginBean.ERROR : 
			msg = "DB 접속 오류! 관리자에게 문의해 주세요";
			url = "main.do";
			break;
		case MerchantLoginBean.DELETE_ID : 
			msg = "사용 중지된 ID입니다.";
			url = "main.do";
			break;
		}
		req.setAttribute("msg", msg);
		req.setAttribute("url", url);
    	return "forward:message.jsp";
	}

	
	@RequestMapping(value="/merchant_join.do", method=RequestMethod.GET)
	public String join() {
		return "merchant/join/merchant_join";
	}
	
	@RequestMapping(value="/merchant_join.do", method=RequestMethod.POST)
	public String joinPro(HttpServletRequest req, @ModelAttribute MerchantDTO dto, BindingResult result) {

    	Map<String, String> comNum = new HashMap<String, String>();
    	comNum.put("mer_comnum1", dto.getMer_comnum1());
    	comNum.put("mer_comnum2", dto.getMer_comnum2());
    	comNum.put("mer_comnum3", dto.getMer_comnum3());
    	MerchantDTO check = merchantMapper.checkBsNum(comNum);
    	if(check != null) {
    		String msg = "이미 가입된 사업자등록번호 입니다.";
    		String url = "merchant_login.do";
    		req.setAttribute("msg", msg);
			req.setAttribute("url", url);
    		return "forward:message.jsp";
    	}
		int res = merchantMapper.insertMerchant(dto);
		
		if (res>0) {
			req.setAttribute("msg", "회원 가입 성공 : 로그인해 주세요");
			req.setAttribute("url", "main.do");
		}else if (res<0){
			req.setAttribute("msg", "회원 가입 실패 : 관리자에게 문의해 주세요");
			req.setAttribute("url", "forward:main.do");
		}
    	return "forward:message.jsp";
	}
	
    public boolean isValid(String str) {
        // �젙洹쒗몴�쁽�떇�쓣 �궗�슜�븯�뿬 �쁺臾�, �닽�옄, - �삉�뒗 _媛� �븘�땶 臾몄옄媛� �룷�븿�릺�뼱 �엳�뒗吏� 寃��궗
        return Pattern.matches("^[a-zA-Z0-9-_]*$", str);
    }
	
    @RequestMapping("/mer_checkId.do")
    @ResponseBody
    public String checkId(@RequestParam("mer_id") String id) {
        String result="N";
        if (merchantMapper.checkMerId(id) != null) result = "Y"; 	// �븘�씠�뵒 �궗�슜 遺덇��뒫
        if (id.trim().equals("")) result = "E";					// �븘�씠�뵒 鍮꾩뼱 �엳�쓣 �븣
        if (id.length() < 5 || id.length() > 12) result = "L";	// length �삤瑜�
        if (isValid(id) == false) result = "V";					// 臾몄옄�뿴 寃��궗
        return result;
    }
    
    @RequestMapping(value="/merchant_logout.do")
    public String logout(HttpServletRequest req) {
    	HttpSession session = req.getSession();
    	session.invalidate();
    	String msg = "로그아웃 되었습니다.";
    	String url = "main.do";
    	req.setAttribute("msg", msg);
    	req.setAttribute("url", url);
    	return "forward:message.jsp";
    }
}
