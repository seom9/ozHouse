package com.oz.ozHouse.dto;

public class Mer_CouponDTO {
	
	private int mer_couponnum;
	private String mer_couponname;
	private String mer_isapproval;
	private String mer_couponimage;
	private int mer_coupondiscount;
	private int mer_num;
	private String mer_couponusedate;
	private String mer_couponenddate;
	
	public int getMer_couponnum() {
		return mer_couponnum;
	}
	public void setMer_couponnum(int mer_couponnum) {
		this.mer_couponnum = mer_couponnum;
	}
	public String getMer_couponname() {
		return mer_couponname;
	}
	public void setMer_couponname(String mer_couponname) {
		this.mer_couponname = mer_couponname;
	}
	public String getMer_isapproval() {
		return mer_isapproval;
	}
	public void setMer_isapproval(String mer_isapproval) {
		this.mer_isapproval = mer_isapproval;
	}
	public String getMer_couponimage() {
		return mer_couponimage;
	}
	public void setMer_couponimage(String mer_couponimage) {
		this.mer_couponimage = mer_couponimage;
	}
	public int getMer_coupondiscount() {
		return mer_coupondiscount;
	}
	public void setMer_coupondiscount(int mer_coupondiscount) {
		this.mer_coupondiscount = mer_coupondiscount;
	}
	public int getMer_num() {
		return mer_num;
	}
	public void setMer_num(int mer_num) {
		this.mer_num = mer_num;
	}
	public String getMer_couponusedate() {
		return mer_couponusedate;
	}
	public void setMer_couponusedate(String mer_couponusedate) {
		this.mer_couponusedate = mer_couponusedate;
	}
	public String getMer_couponenddate() {
		return mer_couponenddate;
	}
	public void setMer_couponenddate(String mer_couponenddate) {
		this.mer_couponenddate = mer_couponenddate;
	}
}
