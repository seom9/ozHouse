package com.oz.ozHouse.merchant.service;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oz.ozHouse.dto.CategoryDTO;
import com.oz.ozHouse.dto.InbrandDTO;
import com.oz.ozHouse.dto.NoticeDTO;
import com.oz.ozHouse.dto.ProductDTO;
import com.oz.ozHouse.dto.RequestProductDTO;

@Service
public class ProductManagementMapper {
	
	@Autowired
	private SqlSession sqlSession;

	
	//category 
	public List<CategoryDTO> listCate() {
		return sqlSession.selectList("listCate");
	}
	
	public InbrandDTO getInbrandByMerNum(String mer_num) {
	    return sqlSession.selectOne("getInbrandByMerNum", mer_num);
	}
	
	public CategoryDTO getCategoryByNum(int category_num) {
	    return sqlSession.selectOne("getCategoryByNum", category_num);
	}
	
	public void processInbrandCategories(String mer_num) {
	    InbrandDTO inbrand = getInbrandByMerNum(mer_num);
	    if (inbrand != null) {
	        String[] categoryNums = inbrand.getInbrand_category().split(",");
	        for (String numStr : categoryNums) {
	            try {
	                int num = Integer.parseInt(numStr.trim());
	                CategoryDTO category = getCategoryByNum(num);
	                if (category != null) {
	                    System.out.println("Category Num: " + category.getCategory_num() + ", Name: " + category.getCategory_name());
	                }
	            } catch (NumberFormatException e) {
	                e.printStackTrace();
	            }
	        }
	    }
	}
	
	//상품등록
	public int insertProduct(ProductDTO dto) {
		return sqlSession.insert("insertProduct", dto);
	}
	
	public int stockListCount(Map<String, String> map) {
	    return sqlSession.selectOne("stockListCount", map);
	}
	
	public int listCount(Map<String, String> map) {
	    return sqlSession.selectOne("listCount", map);
	}

	public int requestListCount(Map<String, String> map) {
	    return sqlSession.selectOne("requestListCount", map);
	}
	
	//상품조회
	public List<ProductDTO> listProduct(Map<String, String> map) {
		return sqlSession.selectList("listProduct", map);
	}
	
	public ProductDTO getProduct(String product_num) {
		java.util.Map<String, String> map = new java.util.Hashtable<>();
		map.put("key", "product_num");
		map.put("value", String.valueOf(product_num));
		return sqlSession.selectOne("getProduct", map);
	}
	
	//수정
	public int updateRe(String product_num) {
		return sqlSession.update("updateRe", product_num);
	}
	//상품수정 폼
	public int insertReProduct(RequestProductDTO dto) {
		return sqlSession.insert("insertReProduct", dto);
	}
	//삭제 요청
	public int deleteRe(String product_num) {
		return sqlSession.update("deleteRe", product_num);
	}
	//재고 수정
	public int updateStock(Map<String, String> params) {
		return sqlSession.update("updateStock", params);
	}
	//재고리스트
	public List<ProductDTO> stockListProduct(Map<String, String> map) {
		return sqlSession.selectList("stockListProduct", map);
	}
	//수정요청 리스트
	public List<ProductDTO> requestListProduct(Map<String, String> map) {
		return sqlSession.selectList("requestListProduct", map);
	}
	//등록 취소
	public int fcancle(Map<String, String> params) {
		return sqlSession.update("fcancle", params);
	}
	//삭제 취소
	public int dcancle(Map<String, String> params) {
		return sqlSession.update("dcancle", params);
	}
	//수정 취소
	public int ucancle(Map<String, String> params) {
		return sqlSession.update("ucancle", params);
	}
	
}
