package com.oz.ozHouse.merchant;

import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.oz.ozHouse.dto.MerchantDTO;
import com.oz.ozHouse.merchant.service.MyInformMapper;


@Controller
public class MyInformController {
	
	@Autowired
	private MyInformMapper myInformMapper;
	
	@RequestMapping(value="/myInform_view.do", method=RequestMethod.GET)
	public String myInform_view(HttpServletRequest req, int mer_num){
		HttpSession session = req.getSession();
		MerchantDTO dto = myInformMapper.myInformView(mer_num);
		String cate[] = dto.getMer_category().split(",");
		String category[] = new String[cate.length];
		for(int i=0; i<category.length; ++i) {
			category[i] = myInformMapper.selectCateName(Integer.valueOf(cate[i]));
		}
		String resultCate = String.join(",", category);
		session.setAttribute("resultCate", resultCate);
		session.setAttribute("merchantUpdate", dto);
		return "merchant/main/myInform_view";
	}
	
	@RequestMapping(value="/myInform_view.do", method=RequestMethod.POST)
	public String myInform_update(HttpServletRequest req, String mode) {
		req.setAttribute("mode", mode);
		return "merchant/main/myInform_updateCheck";
	}
	
	@RequestMapping(value="/myInform_update.do", method=RequestMethod.GET)
	public String myInform_updateForm(HttpServletRequest req, @ModelAttribute MerchantDTO dto) {
		return "merchant/main/myInform_update";
	}
	
	@RequestMapping(value="/myInform_update.do", method=RequestMethod.POST)
	public String myInform_updateFormOk(HttpServletRequest req, @ModelAttribute MerchantDTO dto) {
		int res = myInformMapper.updateMerchant(dto);
		String msg = null, url = "myInform_view.do?mer_num="+dto.getMer_num();
		if(res>0) {
			msg = "정보수정이 완료되었습니다.";
		}else {
			msg = "정보수정을 실패하였습니다.";
		}
		req.setAttribute("msg", msg);
		req.setAttribute("url", url);
		return "forward:message.jsp";
	}
	
	@RequestMapping(value="/myInform_updatePass.do", method=RequestMethod.GET)
	public String myInformUpdatePass() {
		return "merchant/main/myInform_updatePass";
	}
	
	@RequestMapping(value="/myInform_updatePass.do", method=RequestMethod.POST)
	public String myInformUpdatePassOk(HttpServletRequest req, @RequestParam Map<String, String> map) {
		int res = myInformMapper.updatePass(map);
		String msg = null, url = "myInform_view.do?mer_num="+map.get("mer_num");
		if(res>0) {
			msg = "비밀번호 변경이 완료되었습니다.";
		}else {
			msg = "비밀번호 변경이 완료되지 않았습니다.";
		}
		req.setAttribute("msg", msg);
		req.setAttribute("url", url);
		return "forward:message.jsp";
	}
	
	@RequestMapping(value="/memberOut.do", method=RequestMethod.GET)
	public String memberOut(HttpServletRequest req, HttpServletResponse resp, String mer_num) {
		int res = myInformMapper.memberOut(mer_num);
		String msg, url = null;
		if(res>0) {
			msg = "회원 탈퇴가 완료되었습니다. 판매자님의 정보는 개인정보 보호정책에 따라 5년 후 폐기 예정입니다.";
			url = "main.do";
			HttpSession session = req.getSession();
	    	session.invalidate();
	    	Cookie ck = new Cookie("saveId", null);
	    	ck.setMaxAge(0);
	    	resp.addCookie(ck); // 응답에 추가해서 없어지도록 함
		}else {
			msg = "회원 탈퇴 중 오류가 발생하였습니다. 다시 시도하여주세요.";
			url = "myInform_view.do?mer_num=" + mer_num;
		}
		req.setAttribute("msg", msg);
		req.setAttribute("url", url);
		return "forward:message.jsp";
	}

}
