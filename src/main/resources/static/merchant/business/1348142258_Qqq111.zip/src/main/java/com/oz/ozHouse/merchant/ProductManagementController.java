package com.oz.ozHouse.merchant;

import java.io.File;
import java.util.Date;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.oz.ozHouse.dto.ProductDTO;
import com.oz.ozHouse.dto.RequestProductDTO;
import com.oz.ozHouse.dto.CategoryDTO;
import com.oz.ozHouse.dto.InbrandDTO;
import com.oz.ozHouse.dto.NoticeDTO;
import com.oz.ozHouse.merchant.service.ProductManagementMapper;
import com.oz.ozHouse.merchant.service.StoreMainMapper;

@Controller
public class ProductManagementController {
	
	@Autowired
	private ProductManagementMapper productManagementMapper;
	
	//상품등록 폼페이지로 이동
	@RequestMapping(value = {"/productManagement_management.do", "/productManagement_input.do"}, method=RequestMethod.GET)
	public String productManagementInput(HttpServletRequest req, HttpServletResponse resp, @RequestParam Map<String, String> params) throws UnsupportedEncodingException {
		req.setCharacterEncoding("UTF-8");
		resp.setCharacterEncoding("UTF-8");

		InbrandDTO inbrand = productManagementMapper.getInbrandByMerNum(params.get("mer_num"));
	    List<CategoryDTO> selectedCategories = new ArrayList<>();

	    if (inbrand != null && inbrand.getInbrand_category() != null) {
	        String[] categoryNums = inbrand.getInbrand_category().split(",");
	        for (String numStr : categoryNums) {
	            try {
	                int num = Integer.parseInt(numStr.trim());
	                CategoryDTO category = productManagementMapper.getCategoryByNum(num);
	                if (category != null) {
	                    selectedCategories.add(category);
	                }
	            } catch (NumberFormatException e) {}
	        }
	    }
	    req.setAttribute("listCate", selectedCategories);
		return "merchant/store/productManagement/productManagement_input";
	}
	
	//상품등록
	@RequestMapping(value="/productManagement_input.do", method=RequestMethod.POST)
	public String productManagementInput(HttpServletRequest req, @ModelAttribute ProductDTO dto, BindingResult result, int mer_num) {
		if (result.hasErrors()) {
			dto.setProduct_image("");
			dto.setProduct_image_pro("");
		}
		MultipartHttpServletRequest mr = (MultipartHttpServletRequest)req;
		MultipartFile mf = mr.getFile("product_image");
		String filename = mf.getOriginalFilename();
		String path = req.getServletContext().getRealPath("/resources/files");
		File file = new File(path, filename);
		
		MultipartHttpServletRequest mr2 = (MultipartHttpServletRequest)req;
		MultipartFile mf2 = mr2.getFile("product_image_pro");
		String filename2 = mf2.getOriginalFilename();
		String path2 = req.getServletContext().getRealPath("/resources/files1");
		File file2 = new File(path2, filename2);
		
		System.out.println("filename : " + filename);
		System.out.println("path : " + path);
		System.out.println("file : " + file);
		
		
		
		try {
			mf.transferTo(file);
			mf2.transferTo(file2);
		}catch(IOException e) {
			req.setAttribute("msg", "상품 등록에 실패했습니다. 다시 시도하세요.");
			req.setAttribute("url", "productManagement_management.do?mer_num="+dto.getMer_num());
			return "forward:message.jsp";
		}
		HttpSession session = req.getSession();
		dto.setProduct_image(filename);
		dto.setProduct_image_pro(filename2);
		session.setAttribute("product_image", path);
		session.setAttribute("product_image_pro", path2);
		dto.setMer_num(mer_num);
		int res = productManagementMapper.insertProduct(dto);
		if (res>0) {
			req.setAttribute("msg", "상품 등록에 성공했습니다.");
			req.setAttribute("url", "productManagement_productList.do?mer_num="+dto.getMer_num());
		}else {
			req.setAttribute("msg", "상품 등록에 실패했습니다. 다시 시도하세요.");
			req.setAttribute("url", "productManagement_input.do?mer_num="+dto.getMer_num());
		}
		return "forward:message.jsp";
		}
	
	private String convertDateFormat(String originalDate) {
	    SimpleDateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd");
	    SimpleDateFormat targetFormat = new SimpleDateFormat("yy/MM/dd");
	    try {
	        Date date = originalFormat.parse(originalDate);
	        return targetFormat.format(date);
	    } catch (ParseException e) {
	        e.printStackTrace();
	        return null;
	    }
	}

	
	//상품조회 페이지로 이동
	@RequestMapping("/productManagement_productList.do")
	public String productManagementList(HttpServletRequest req, @RequestParam Map<String, String> params) {
		if(params.containsKey("startDate")) {
	        String formattedStartDate = convertDateFormat(params.get("startDate"));
	        params.put("startDate", formattedStartDate);
	    }
		if(params.containsKey("endDate")) {
	        String formattedEndDate = convertDateFormat(params.get("endDate"));
	        params.put("endDate", formattedEndDate);
	    }
//		System.out.println(params.get("startDate"));
//		System.out.println(params.get("endDate"));
		List<ProductDTO> list = productManagementMapper.listProduct(params);
		int listCount = productManagementMapper.listCount(params);
		req.setAttribute("listProduct", list);
		req.setAttribute("listCount", listCount);
		return "merchant/store/productManagement/productManagement_list";
	}
	
	//상품수정 폼페이지
	@RequestMapping(value="/product_update.do", method=RequestMethod.GET)
	public String productUpdate(HttpServletRequest req, @RequestParam Map<String, String> params) {
		
		InbrandDTO inbrand = productManagementMapper.getInbrandByMerNum(params.get("mer_num"));
	    List<CategoryDTO> selectedCategories = new ArrayList<>();

	    if (inbrand != null && inbrand.getInbrand_category() != null) {
	        String[] categoryNums = inbrand.getInbrand_category().split(",");
	        for (String numStr : categoryNums) {
	            try {
	                int num = Integer.parseInt(numStr.trim());
	                CategoryDTO category = productManagementMapper.getCategoryByNum(num);
	                if (category != null) {
	                    selectedCategories.add(category);
	                }
	            } catch (NumberFormatException e) {}
	        }
	    }
	    req.setAttribute("listCate", selectedCategories);
		ProductDTO dto = productManagementMapper.getProduct(params.get("product_num"));
		req.setAttribute("getProduct", dto);
		return "merchant/store/productManagement/productManagement_update";
	}
	
	//상품수정 요청
	@RequestMapping(value="/product_update.do", method=RequestMethod.POST)
	public String productUpdate(HttpServletRequest req, @ModelAttribute RequestProductDTO dto, BindingResult result,  @RequestParam Map<String, String> params) {
		if (result.hasErrors()) {
			dto.setProduct_image("");
			dto.setProduct_image_pro("");
		}
		MultipartHttpServletRequest mr = (MultipartHttpServletRequest)req;
		MultipartFile mf = mr.getFile("product_image");
		String filename = mf.getOriginalFilename();
		String path = req.getServletContext().getRealPath("/resources/files");
		File file = new File(path, filename);
		MultipartHttpServletRequest mr2 = (MultipartHttpServletRequest)req;
		MultipartFile mf2 = mr2.getFile("product_image_pro");
		String filename2 = mf2.getOriginalFilename();
		String path2 = req.getServletContext().getRealPath("/resources/files1");
		File file2 = new File(path2, filename2);
		try {
			mf.transferTo(file);
			mf2.transferTo(file2);
		}catch(IOException e) {
			req.setAttribute("msg", "상품 수정에 실패했습니다. 다시 시도하세요.");
			req.setAttribute("url", "productManagement_management.do?mer_num="+params.get("mer_num"));
			return "forward:message.jsp";
		}
		HttpSession session = req.getSession();
		dto.setProduct_image(filename);
		dto.setProduct_image_pro(filename2);
		session.setAttribute("product_image", path);
		session.setAttribute("product_image_pro", path2);
		int res1 = productManagementMapper.insertReProduct(dto);
		int res = productManagementMapper.updateRe(params.get("product_num"));
		if (res > 0) {
			req.setAttribute("msg", "상품 수정 요청에 성공했습니다.");
			req.setAttribute("url", "productManagement_requestList.do?mer_num="+params.get("mer_num"));
		}else {
			req.setAttribute("msg", "상품 수정 요청에 실패했습니다. 다시 시도하세요.");
			req.setAttribute("url", "productManagement_productList.do?mer_num="+params.get("mer_num"));
		}
		return "forward:message.jsp";
	}
	
	//상품삭제 요청
	@RequestMapping("/product_delete.do")
	public String deleteRe (HttpServletRequest req, @RequestParam Map<String, String> params) {
		int res = productManagementMapper.deleteRe(params.get("product_num"));
		if (res > 0) {
			req.setAttribute("msg", "상품 삭제 요청에 성공했습니다.");
			req.setAttribute("url", "productManagement_requestList.do?mer_num="+params.get("mer_num"));
		}else {
			req.setAttribute("msg", "상품 삭제 요청에 실패했습니다. 다시 시도하세요.");
			req.setAttribute("url", "productManagement_productList.do?mer_num="+params.get("mer_num"));
		}
		return "forward:message.jsp";
	}
	
	//상품요청 리스트
	@RequestMapping("/productManagement_requestList.do")
	public String productManagementRequestList(HttpServletRequest req, @RequestParam Map<String, String> params) {
		if(params.containsKey("startDate")) {
	        String formattedStartDate = convertDateFormat(params.get("startDate"));
	        params.put("startDate", formattedStartDate);
	    }
		if(params.containsKey("endDate")) {
	        String formattedEndDate = convertDateFormat(params.get("endDate"));
	        params.put("endDate", formattedEndDate);
	    }
		List<ProductDTO> list = productManagementMapper.requestListProduct(params);
		int requestListCount = productManagementMapper.requestListCount(params);
		req.setAttribute("requestListProduct", list);
		req.setAttribute("requestListCount", requestListCount);
		return "merchant/store/productManagement/productManagement_request_list";
	}
	
	//재고관리 리스트
	@RequestMapping("/productManagement_stock.do")
	public String productManagementStockList(HttpServletRequest req, @RequestParam Map<String, String> params) {
		if(params.containsKey("startDate")) {
	        String formattedStartDate = convertDateFormat(params.get("startDate"));
	        params.put("startDate", formattedStartDate);
	    }
		if(params.containsKey("endDate")) {
	        String formattedEndDate = convertDateFormat(params.get("endDate"));
	        params.put("endDate", formattedEndDate);
	    }
		List<ProductDTO> list = productManagementMapper.stockListProduct(params);
		int stockListCount = productManagementMapper.stockListCount(params);
		req.setAttribute("stockListProduct", list);
		req.setAttribute("stockListCount", stockListCount);
		return "merchant/store/productManagement/productManagement_stock";
	}
	
	//재고수정
	@RequestMapping("/stock_update.do")
	public String stockUpdate(HttpServletRequest req, @RequestParam Map<String, String> params) {
		req.setAttribute("mer_num", params.get("mer_num"));
	    int res = productManagementMapper.updateStock(params);
	    String url = "productManagement_stock.do?mer_num="+params.get("mer_num");
	    if (res > 0) {
	        req.setAttribute("msg", "재고 수정에 성공했습니다.");
	        req.setAttribute("url", url);
	    } else {
	        req.setAttribute("msg", "재고 수정에 실패했습니다.");
	        req.setAttribute("url", url);
	    }
	    return "forward:message.jsp";
	}

	//등록 신청 철회
	@RequestMapping("/product_fcancle.do")
	public String approvalfCancle(HttpServletRequest req, @RequestParam Map<String, String> params) {
		req.setAttribute("mer_num", params.get("mer_num"));
		int res = productManagementMapper.fcancle(params);
		String url = "productManagement_requestList.do?mer_num="+params.get("mer_num");
		if (res > 0) {
			req.setAttribute("msg", "등록 신청철회 완료!");
			req.setAttribute("url", url);
		}else {
			req.setAttribute("msg", "등록 신청철회 실패. 다시 시도하십시오.");
			req.setAttribute("url", url);
		}
		return "forward:message.jsp";
	}
	
	//삭제 신청 철회
	@RequestMapping("/product_dcancle.do")
	public String approvaldCancle(HttpServletRequest req, @RequestParam Map<String, String> params) {
		req.setAttribute("mer_num", params.get("mer_num"));
		int res = productManagementMapper.dcancle(params);
		String url = "productManagement_requestList.do?mer_num="+params.get("mer_num");
		if (res > 0) {
			req.setAttribute("msg", "삭제 신청철회 완료!");
			req.setAttribute("url", url);
		}else {
			req.setAttribute("msg", "삭제 신청철회 실패. 다시 시도하십시오.");
			req.setAttribute("url", url);
		}
		return "forward:message.jsp";
	}
	
	//수정 신청 철회
	@RequestMapping("/product_ucancle.do")
	public String approvaluCancle(HttpServletRequest req, @RequestParam Map<String, String> params) {
		req.setAttribute("mer_num", params.get("mer_num"));
		int res = productManagementMapper.ucancle(params);
		String url = "productManagement_requestList.do?mer_num="+params.get("mer_num");
		if (res > 0) {
			req.setAttribute("msg", "삭제 신청철회 완료!");
			req.setAttribute("url", url);
		}else {
			req.setAttribute("msg", "삭제 신청철회 실패. 다시 시도하십시오.");
			req.setAttribute("url", url);
		}
		return "forward:message.jsp";
	}
}
