package com.oz.ozHouse.merchant.service;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oz.ozHouse.dto.Mer_CouponDTO;

@Service
public class CouponMapper {

	@Autowired
	private SqlSession sqlSession;
	
	public int couponInsert(Mer_CouponDTO dto) {
		int res = sqlSession.insert("couponInsert", dto);
		return res;
	}
	
	public List<Mer_CouponDTO> couponList(int mer_num){
		List<Mer_CouponDTO> list = sqlSession.selectList("couponList", mer_num);
		return list;
	}
	
	public List<Mer_CouponDTO> searchCouponList(Map map){
		List<Mer_CouponDTO> list = sqlSession.selectList("searchCouponList", map);
		return list;
	}
	
	public int couponDelete(int mer_couponnum) {
		int res = sqlSession.delete("couponDelete", mer_couponnum);
		return res;
	}
	
	public int couponCount(int mer_num) {
		int couponCount = sqlSession.selectOne("couponCount", mer_num);
		return couponCount;
	}
	
	public int couponSearchCount(Map map) {
		int couponSearchCount = sqlSession.selectOne("couponSearchCount", map);
		return couponSearchCount;
	}
}
