package com.oz.ozHouse.dto;

public class Admin_QA_DTO {

	private int admint_QA_num;
	private String member_id;
	private String admin_QA_subject;
	private String admin_QA_content;
	private String admin_QA_date;
	private int admin_QA_re_level;
	private int admin_QA_re_step;
	private String admin_inquiry_type;
	private String admin_QA_state;
	
	public int getAdmint_QA_num() {
		return admint_QA_num;
	}
	public void setAdmint_QA_num(int admint_QA_num) {
		this.admint_QA_num = admint_QA_num;
	}
	public String getMember_id() {
		return member_id;
	}
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}
	public String getAdmin_QA_subject() {
		return admin_QA_subject;
	}
	public void setAdmin_QA_subject(String admin_QA_subject) {
		this.admin_QA_subject = admin_QA_subject;
	}
	public String getAdmin_QA_content() {
		return admin_QA_content;
	}
	public void setAdmin_QA_content(String admin_QA_content) {
		this.admin_QA_content = admin_QA_content;
	}
	public String getAdmin_QA_date() {
		return admin_QA_date;
	}
	public void setAdmin_QA_date(String admin_QA_date) {
		this.admin_QA_date = admin_QA_date;
	}
	public int getAdmin_QA_re_level() {
		return admin_QA_re_level;
	}
	public void setAdmin_QA_re_level(int admin_QA_re_level) {
		this.admin_QA_re_level = admin_QA_re_level;
	}
	public int getAdmin_QA_re_step() {
		return admin_QA_re_step;
	}
	public void setAdmin_QA_re_step(int admin_QA_re_step) {
		this.admin_QA_re_step = admin_QA_re_step;
	}
	public String getAdmin_inquiry_type() {
		return admin_inquiry_type;
	}
	public void setAdmin_inquiry_type(String admin_inquiry_type) {
		this.admin_inquiry_type = admin_inquiry_type;
	}
	public String getAdmin_QA_state() {
		return admin_QA_state;
	}
	public void setAdmin_QA_state(String admin_QA_state) {
		this.admin_QA_state = admin_QA_state;
	}
	
}
