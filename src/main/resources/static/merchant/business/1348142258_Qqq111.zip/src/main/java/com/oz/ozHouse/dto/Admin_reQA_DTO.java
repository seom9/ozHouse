package com.oz.ozHouse.dto;

public class Admin_reQA_DTO {

	private int admin_reQA_num;
	private String member_id;
	private String admin_reQA_subject;
	private String admin_reQA_content;
	private String Admin_reQA_date;
	private int Admin_reQA_re_level;
	private int Admin_reQA_re_step;
	public int getAdmin_reQA_num() {
		return admin_reQA_num;
	}
	public void setAdmin_reQA_num(int admin_reQA_num) {
		this.admin_reQA_num = admin_reQA_num;
	}
	public String getMember_id() {
		return member_id;
	}
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}
	public String getAdmin_reQA_subject() {
		return admin_reQA_subject;
	}
	public void setAdmin_reQA_subject(String admin_reQA_subject) {
		this.admin_reQA_subject = admin_reQA_subject;
	}
	public String getAdmin_reQA_content() {
		return admin_reQA_content;
	}
	public void setAdmin_reQA_content(String admin_reQA_content) {
		this.admin_reQA_content = admin_reQA_content;
	}
	public String getAdmin_reQA_date() {
		return Admin_reQA_date;
	}
	public void setAdmin_reQA_date(String admin_reQA_date) {
		Admin_reQA_date = admin_reQA_date;
	}
	public int getAdmin_reQA_re_level() {
		return Admin_reQA_re_level;
	}
	public void setAdmin_reQA_re_level(int admin_reQA_re_level) {
		Admin_reQA_re_level = admin_reQA_re_level;
	}
	public int getAdmin_reQA_re_step() {
		return Admin_reQA_re_step;
	}
	public void setAdmin_reQA_re_step(int admin_reQA_re_step) {
		Admin_reQA_re_step = admin_reQA_re_step;
	}
	
	
}
