package com.oz.ozHouse.dto;

public class Order_reQADTO {

	private int order_reQA_num ;
	private String member_id;
	private String order_reQA_content;
	private String order_reQA_date;
	
	public int getOrder_reQA_num() {
		return order_reQA_num;
	}
	public void setOrder_reQA_num(int order_reQA_num) {
		this.order_reQA_num = order_reQA_num;
	}
	public String getMember_id() {
		return member_id;
	}
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}
	public String getOrder_reQA_content() {
		return order_reQA_content;
	}
	public void setOrder_reQA_content(String order_reQA_content) {
		this.order_reQA_content = order_reQA_content;
	}
	public String getOrder_reQA_date() {
		return order_reQA_date;
	}
	public void setOrder_reQA_date(String order_reQA_date) {
		this.order_reQA_date = order_reQA_date;
	}
}
